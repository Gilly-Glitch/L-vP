Lambwath vs Pelican — GitHub Pages offline bundle

Contents:
- index.html: British caller and commentary app
- sw.js: same-origin service worker for offline caching
- manifest.json: installable web app metadata
- icon.svg: app icon
- lambwath-vs-pelican.html: optional copy of the original file name is not included; index.html is the Pages entry point

Publish on GitHub Pages:
1. Open your repository: https://github.com/Gilly-Glitch/L-vP
2. Add/upload index.html, sw.js, manifest.json, and icon.svg to the repository root (keep your existing lambwath-vs-pelican.html if you want).
3. In repository Settings > Pages, set Source to "Deploy from a branch", choose main and /(root), then Save.
4. Wait for GitHub Pages to finish publishing. The site URL should be https://gilly-glitch.github.io/L-vP/
5. Open the published site once in Safari while online. Then use Share > Add to Home Screen.
6. Launch it from the Home Screen once online so the service worker can finish caching. After that, the app shell should load offline.

Offline note:
The app uses browser speech synthesis. It will use an installed British English voice where available; the voice itself is provided by iOS/browser and is not bundled in this ZIP. Some iOS versions may need one initial online visit before caching takes effect.
